
public class Job {

	private int start;
	private int length;
	
	public Job(int st, int lg){
		start = st;
		length = lg;
	}
	
	public int getStart(){
		return start;
	}
	
	public int getLenth(){
		return length;
	}
}
